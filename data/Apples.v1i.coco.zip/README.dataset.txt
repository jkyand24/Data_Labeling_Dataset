# Apples > 2023-06-19 10:58am
https://universe.roboflow.com/ms-ai-school/apples-zgajg

Provided by a Roboflow user
License: CC BY 4.0

